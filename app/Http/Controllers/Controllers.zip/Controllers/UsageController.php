<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Response;
use PDF;
use App\Jobs\EmailScheduleJobs;
use App;


class UsageController extends Controller
{
    public function index(Request $req){

        if($req->ajax()){
            $sort_by   = $req->get('sortby');
            $sort_type = $req->get('sorttype');
            $asset  = $req->get('asset');

            if($asset == ''){
                $data = DB::table('asset_mstr')
                            // ->leftJoin('asset_usage_hist','asset_mstr.asset_code','=','asset_usage_hist.asset_code')
                            ->where('asset_measure','=','M')
                            ->selectRaw('*, asset_mstr.asset_code as "assetcode"')
                            // ->groupBy('asset_mstr.asset_code')
                            // ->orderBy('asset_usage_hist.last_checked')
                            ->orderby($sort_by, $sort_type)
                            ->paginate(10);
                            
            }else{
                $data = DB::table('asset_mstr')
                            // ->leftJoin('asset_usage_hist','asset_mstr.asset_code','=','asset_usage_hist.asset_code')
                            ->where('asset_measure','=','M')
                            ->where('asset_mstr.asset_code','=',$asset)
                            ->selectRaw('*, asset_mstr.asset_code as "assetcode"')
                            // ->groupBy('asset_mstr.asset_code')
                            // ->orderBy('asset_usage_hist.last_checked')
                            ->orderby($sort_by, $sort_type)
                            ->paginate(10);

            }

            return view('schedule.table-usage', ['data' => $data]);


        }else{
            $data = DB::table('asset_mstr')
                        // ->leftJoin('asset_usage_hist','asset_mstr.asset_code','=','asset_usage_hist.asset_code')
                        ->where('asset_measure','=','M')
                        ->selectRaw('*, asset_mstr.asset_code as "assetcode"')
                        // ->groupBy('asset_mstr.asset_code')
                        // ->orderBy('asset_usage_hist.last_checked')
                        ->paginate(10);

            $asset = DB::table('asset_mstr')
                            ->get();
        

            return view('schedule.usage',['data' => $data, 'asset' => $asset]);
        }

        
    }

    public function updateusage(Request $req){
		
        $checkdata = DB::table('asset_mstr')
                    ->where('asset_code','=',$req->e_asset)
                    ->first();

        if($checkdata){

            if(is_null($checkdata->asset_last_usage)){
                DB::table('asset_mstr')
                    ->where('asset_code','=',$req->e_asset)
                    ->update([
                            'asset_last_usage' => $req->e_current,
                            'asset_last_usage_mtc' => $req->e_current,
                    ]);
            }else{
                $nextusage = $checkdata->asset_last_usage + $checkdata->asset_meter;

                if($nextusage <= $req->e_current){
                    DB::table('asset_mstr')
                    ->where('asset_code','=',$req->e_asset)
                    ->update([
                            'asset_last_usage' => $req->e_current,
                            'asset_last_usage_mtc' => $req->e_current,
                    ]);
                    
                    // Buat WO

                    $tablern = DB::table('running_mstr')
                                ->first();

                    $tempnewrunnbr = strval(intval($tablern->wt_nbr)+1);
                    $newtemprunnbr = '';

                    if(strlen($tempnewrunnbr) <= 4){
                    $newtemprunnbr = str_pad($tempnewrunnbr,4,'0',STR_PAD_LEFT);
                    }

                    $runningnbr = $tablern->wt_prefix.'-'.$tablern->year.'-'.$newtemprunnbr;
                    
                    // dd($runningnbr);
                    $dataarray = array(
                        'wo_nbr' => $runningnbr,
                        'wo_status' => 'plan',
						'wo_priority' => 'high',
                        'wo_asset' => $req->e_asset, 
                        'wo_schedule' => Carbon::now('ASIA/JAKARTA')->toDateString(),
                        'wo_duedate' => Carbon::now('ASIA/JAKARTA')->toDateString(),
                        'wo_created_at' => Carbon::now('ASIA/JAKARTA')->toDateTimeString(),
                        'wo_updated_at' => Carbon::now('ASIA/JAKARTA')->toDateTimeString(),
                    );

                    DB::table('wo_mstr')->insert($dataarray);

                    DB::table('running_mstr')
                        ->update([
                            'wt_nbr' => $newtemprunnbr
                        ]);

                    // Kirim Email
                    $assettable = DB::table('asset_mstr')
                                ->where('asset_code','=',$req->e_asset)
                                ->first();
                
                    $asset = $req->e_asset.' - '.$assettable->asset_desc;

                    EmailScheduleJobs::dispatch($runningnbr,$asset,'1','','','','');

                    toast('Data Updated & WO Succesfully Created', 'success');
                    return back();
                }else{
                    DB::table('asset_mstr')
                    ->where('asset_code','=',$req->e_asset)
                    ->update([
                            'asset_last_usage_mtc' => $req->e_current,
                    ]);
                }
            }


            toast('Data Updated', 'success');
            return back();

        }else{
            toast('Error No data Available', 'error');
            return back();
        }
    }


    //ditambahkan 03/11/2020
    public function notifread(Request $req){
        auth()->user()
        ->unreadNotifications
        ->when($req->input('id'), function ($query) use ($req) {
            return $query->where('id', $req->input('id'));
        })
        ->markAsRead();
         
        // DB::table('notifications')->where('id', '=', $req->input('id'))->delete();

        return response()->noContent();
        
    }
    
    public function notifreadall(Request $req){
       
      auth()->user()->unreadNotifications()->update(['read_at' => now()]);
      // DB::table('notifications')->where('id', '=', $req->input('id'))->delete();
      
      return response()->noContent();
    }
    
}
