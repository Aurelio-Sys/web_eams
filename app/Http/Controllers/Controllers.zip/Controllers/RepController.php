<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class RepController extends Controller
{
    public function repgroup()
    {
	    $data = DB::table('xxrepgroup_mstr')
            ->select('xxrepgroup_nbr','xxrepgroup_desc')
            ->groupby('xxrepgroup_nbr')
            ->orderby('xxrepgroup_nbr')
            ->paginate(10);

        $dataasset = DB::table('rep_master')
            ->orderby('repm_code')
            ->get();

        return view('setting.repgroup', ['data' => $data, 'dataasset' => $dataasset]);     
    }
    
    public function createrepgroup(Request $req)
    {
			
        // harus ada inputan anak
        if (is_null($req->line)) {
            toast('Please Line Items!!', 'error');
             return back();
        }

        if (is_null($req->barang)) {
            toast('Please Input Repair Code!!', 'error');
             return back();
        }
        
           $flg = 0;
        foreach($req->barang as $barang){
            DB::table('xxrepgroup_mstr')
            ->insert([
                'xxrepgroup_nbr'     => $req->t_code,
				'xxrepgroup_desc'     => $req->t_desc,
				'xxrepgroup_line'   => $req->line[$flg],
                'xxrepgroup_rep_code'   => $req->barang[$flg],      
                
            ]);

            $flg += 1;
        }    

        toast('Repair Group Created.', 'success');
        return back();
    }

    //menampilkan detail edit
    public function editdetailrepgroup(Request $req)
    {
        if ($req->ajax()) {
            $data = DB::table('xxrepgroup_mstr')
                    ->where('xxrepgroup_nbr','=',$req->code)
                    ->get();

            $dataRep = DB::table('rep_master')
                    ->get();

            $output = '';
            foreach ($data as $data) {
                $descRep = $dataRep->where('repm_code','=',$data->xxrepgroup_rep_code)->first();
                $a = $descRep->repm_desc.' -- '.$descRep->repm_ref;

                $output .= '<tr>'.
                            '<td><input type="text" class="form-control" name="line[]" readonly value="'.$data->xxrepgroup_line.'"></td>'.
                            '<td><input type="text" class="form-control" name="barang[]" readonly value="'.$data->xxrepgroup_rep_code.'">'.$a.'</td>'.
                            '<td><input type="checkbox" name="cek[]" class="cek" id="cek" value="0">
                            <input type="hidden" name="tick[]" id="tick" class="tick" value="0"></td>'.
                            '</tr>';
            }

            return response($output);
        }
    }
	
    public function editrepgroup(Request $req)
    {

        DB::table('xxrepgroup_mstr')
            ->where('xxrepgroup_nbr','=',$req->h_code)
            ->delete();

        $flg = 0;
        foreach($req->barang as $barang){
            /* tick = 0 --> tidak dicentang delete, dan di save */
            if ($req->tick[$flg] == 0) {
                DB::table('xxrepgroup_mstr')
                ->insert([
                    'xxrepgroup_nbr'     => $req->h_code,
                    'xxrepgroup_desc'     => $req->h_desc,
                    'xxrepgroup_line'   => $req->line[$flg],
                    'xxrepgroup_rep_code'   => $req->barang[$flg],      
                ]);
            }            

            $flg += 1;
        }    

        toast('Repair Group Updated.', 'success');
        return back();
    }

	 public function deleterepgroup(Request $req)
    {
			
        DB::table('xxrepgroup_mstr')
            ->where('xxrepgroup_nbr', '=', $req->d_code)
            ->delete();

        toast('Deleted Repair Group Successfully.', 'success');
        return back();
    }
	
    public function repgrouppagination(Request $req)
    {
        if ($req->ajax()) {
            $sort_by = $req->get('sortby');
            $sort_group = $req->get('sorttype');
            $code = $req->get('code');
            $desc = $req->get('desc');

            $dataasset = DB::table('rep_master')
            ->orderby('repm_code')
            ->get();
      
            if ($code == '' && $desc == '') {
                $data = DB::table('xxrepgroup_mstr')
                    ->orderby('xxrepgroup_nbr')
                    ->paginate(10);

                return view('setting.table-repgroup', ['data' => $data]);
            } else {
                $kondisi = '';
                if ($code != '') {
                    $kondisi = 'xxrepgroup_nbr like "%' . $code . '%"';
                }
                if ($desc != '') {
                    if ($kondisi != '') {
                        $kondisi .= ' and xxrepgroup_desc like "%' . $desc . '%"';
                    } else {
                        $kondisi = 'xxrepgroup_desc like "%' . $desc . '%"';
                    }
                }
                
                $data = DB::table('xxrepgroup_mstr')
                    ->whereRaw($kondisi)
                    ->orderby('xxrepgroup_nbr')
                    ->paginate(10);

                return view('setting.table-repgroup', ['data' => $data]);
            }
        }
    }
}
