<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class dashController extends Controller
{
    public function openwo()
    {
	  $data = DB::table('wo_mstr')->where('wo_status', 'open')	
               ->join('asset_mstr', 'wo_mstr.wo_asset', '=', 'asset_mstr.asset_code')       
					->get();								
       return view('/dash/openwo',['openwo'=>$data]);    
    }
    
     public function startwo()
    {
	  $data = DB::table('wo_mstr')->where('wo_status', 'started')
          ->join('asset_mstr', 'wo_mstr.wo_asset', '=', 'asset_mstr.asset_code')       
		->get();								
       return view('/dash/startwo',['openwo'=>$data]);    
    }
	
       public function planwo()
    {
	  $data = DB::table('wo_mstr')->where('wo_status', 'plan')
          ->join('asset_mstr', 'wo_mstr.wo_asset', '=', 'asset_mstr.asset_code')       
		->get();								
       return view('/dash/planwo',['openwo'=>$data]);    
    }
    
     public function finishwo()
    {
	  $data = DB::table('wo_mstr')->where('wo_status', 'finish')
          ->join('asset_mstr', 'wo_mstr.wo_asset', '=', 'asset_mstr.asset_code')       
		->get();								
       return view('/dash/finishwo',['openwo'=>$data]);    
    }
    
         public function closewo()
    {
	  $data = DB::table('wo_mstr')->where('wo_status', 'closed')
          ->join('asset_mstr', 'wo_mstr.wo_asset', '=', 'asset_mstr.asset_code')       
		->get();								
       return view('/dash/closewo',['openwo'=>$data]);    
    }

}
