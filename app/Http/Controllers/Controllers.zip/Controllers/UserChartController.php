<?php

namespace App\Http\Controllers;

use App\Charts\UserChart;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Schema;

use Carbon\Carbon;

class UserChartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $chart = new UserChart;
        $chart->labels(['senin','selasa','rabu','kamis','jumat','sabtu','minggu']);
        $chart->dataset('Laporan Pendapatan', 'line', ['9000','7000','4000','12000','10000','15000','18000']);

        return view('report.users', compact('chart'));
    }

    public function rptwo()
    {
        $borderColors = [
            "rgba(255, 99, 132, 1.0)",
            "rgba(22,160,133, 1.0)",
            "rgba(255, 205, 86, 1.0)",
            "rgba(51,105,232, 1.0)",
            "rgba(244,67,54, 1.0)",
            "rgba(34,198,246, 1.0)",
            "rgba(153, 102, 255, 1.0)",
            "rgba(255, 159, 64, 1.0)",
            "rgba(233,30,99, 1.0)",
            "rgba(205,220,57, 1.0)"
        ];
        $fillColors = [
            "rgba(255, 99, 132, 0.2)",
            "rgba(22,160,133, 0.2)",
            "rgba(255, 205, 86, 0.2)",
            "rgba(51,105,232, 0.2)",
            "rgba(244,67,54, 0.2)",
            "rgba(34,198,246, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(233,30,99, 0.2)",
            "rgba(205,220,57, 0.2)"
        ];

        $totals = DB::table('wo_mstr')
            ->selectRaw('count(*) as total')
            ->selectRaw("count(case when DATEDIFF(NOW(),wo_created_at) <= 3 then 1 end) as a")
            ->selectRaw("count(case when DATEDIFF(NOW(),wo_created_at) > 3 and DATEDIFF(NOW(),wo_created_at) <= 3 then 1 end) as b")
            ->selectRaw("count(case when DATEDIFF(NOW(),wo_created_at) > 5 then 1 end) as c")
            ->first();

        $jml = [];
        $jml[] = $totals->a;
        $jml[] = $totals->b;
        $jml[] = $totals->c;

        $chart = new UserChart;
        $chart->labels(['wo < 3days','3days < wo < 5days','wo > 5days']);
        $chart->dataset('Status Work Order', 'bar', $jml)
            ->color($borderColors)
            ->backgroundcolor($fillColors);

        $totsr = DB::table('service_req_mstr')
            ->selectRaw('count(*) as total')
            ->selectRaw("count(case when DATEDIFF(NOW(),sr_created_at) <= 3 then 1 end) as a")
            ->selectRaw("count(case when DATEDIFF(NOW(),sr_created_at) > 3 and DATEDIFF(NOW(),sr_created_at) <= 3 then 1 end) as b")
            ->selectRaw("count(case when DATEDIFF(NOW(),sr_created_at) > 5 then 1 end) as c")
            ->first();

        $jmlsr = [];
        $jmlsr[] = $totsr->a;
        $jmlsr[] = $totsr->b;
        $jmlsr[] = $totsr->c;

        $chartsr = new UserChart;
        $chartsr->labels(['sr < 3days','3days < sr < 5days','sr > 5days']);
        $chartsr->dataset('Status Service Request', 'bar', $jmlsr)
            ->color($borderColors)
            ->backgroundcolor($fillColors);

        $totasset = DB::table('wo_mstr')
                ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                ->where('wo_status','=','started')
                ->groupby('wo_asset')
                ->get();

        $asset = [];
        foreach ($totasset as $ta) {
            $asset[] = $ta->wo_asset;
        }

        $jmlasset = [];
        foreach ($totasset as $tta) {
            $jmlasset[] = $tta->jmlasset;
        }

        $chartasset = new UserChart;
        $chartasset->labels($asset);
        $chartasset->dataset('Status Asset', 'bar', $jmlasset)
            ->color($borderColors)
            ->backgroundcolor($fillColors);

        return view('report.rptwo', compact('chart','chartsr','chartasset','datawo'));

    }

    public function topten() 
    {
        $borderColors = [
            "rgba(255, 99, 132, 1.0)",
            "rgba(22,160,133, 1.0)",
            "rgba(255, 205, 86, 1.0)",
            "rgba(51,105,232, 1.0)",
            "rgba(244,67,54, 1.0)",
            "rgba(34,198,246, 1.0)",
            "rgba(153, 102, 255, 1.0)",
            "rgba(255, 159, 64, 1.0)",
            "rgba(233,30,99, 1.0)",
            "rgba(205,220,57, 1.0)"
        ];
        $fillColors = [
            "rgba(255, 99, 132, 0.2)",
            "rgba(22,160,133, 0.2)",
            "rgba(255, 205, 86, 0.2)",
            "rgba(51,105,232, 0.2)",
            "rgba(244,67,54, 0.2)",
            "rgba(34,198,246, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(233,30,99, 0.2)",
            "rgba(205,220,57, 0.2)"
        ];

        $skrg = Carbon::now('ASIA/JAKARTA')->toDateTimeString();
        $lalu = Carbon::now('ASIA/JAKARTA')->addYear(-1)->toDateTimeString();

        $totasset = DB::table('wo_mstr')
                    ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                    ->whereBetween('wo_created_at',[$lalu,$skrg])
                    ->groupby('wo_asset')
                    ->limit(10)
                    ->get();

        $asset = [];
        foreach ($totasset as $ta) {
            $asset[] = $ta->wo_asset;
        }

        $jmlasset = [];
        foreach ($totasset as $tta) {
            $jmlasset[] = $tta->jmlasset;
        }

        $chartasset = new UserChart;
        $chartasset->labels($asset);
        $chartasset->dataset('Status Asset', 'bar', $jmlasset)
            ->color($borderColors)
            ->backgroundcolor($fillColors);

        $non = DB::table('wo_mstr')
                ->select('wo_asset')
                ->groupby('wo_asset')
                ->get();

        $totnon = DB::table('asset_mstr')
                ->whereNotIn('asset_code',DB::table('wo_mstr')->groupby('wo_status')->pluck('wo_asset')->toArray())
                ->limit(10)
                ->get();

        $tophealthy = DB::table('asset_mstr')
            ->whereNotIn('asset_code',DB::table('wo_mstr')->groupby('wo_asset')->pluck('wo_asset')->toArray())
            ->limit(10)
            ->get();

        $skrg = Carbon::now('ASIA/JAKARTA')->toDateTimeString();
        $lalu = Carbon::now('ASIA/JAKARTA')->addYear(-1)->toDateTimeString();

        $topprob = DB::table('wo_mstr')
                    ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                    ->whereBetween('wo_created_at',[$lalu,$skrg])
                    ->groupby('wo_asset')
                    ->orderby('jmlasset','desc')
                    ->limit(10)
                    ->get();

        $dataasset = DB::table('asset_mstr')
                    ->get();

        return view('report.topten', compact('chartasset','tophealthy','topprob','dataasset'));
    }

    public function topprob()
    {
        $skrg = Carbon::now('ASIA/JAKARTA')->toDateTimeString();
        $lalu = Carbon::now('ASIA/JAKARTA')->addYear(-1)->toDateTimeString();

        $data = DB::table('wo_mstr')
                    ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                    ->whereBetween('wo_created_at',[$lalu,$skrg])
                    ->groupby('wo_asset')
                    ->orderby('jmlasset','desc')
                    ->paginate(5);

        $dataasset = DB::table('asset_mstr')
                    ->get();

        return view('report.topprob', compact('data','dataasset'));
    }

    public function topprobpagination(Request $req)
    {
        if ($req->ajax()) {
            $sort_by = $req->get('sortby');
            $sort_type = $req->get('sorttype');
            $code = $req->get('code');
            $desc = $req->get('desc');

            $dataasset = DB::table('asset_mstr')
                    ->get();

            if ($code == '' && $desc == '') {
                $data = DB::table('wo_mstr')
                    ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                    ->whereBetween('wo_created_at',[$lalu,$skrg])
                    ->groupby('wo_asset')
                    ->orderby('jmlasset','desc')
                    ->paginate(5);

                return view('report.table-topprob', compact('data','$dataasset'));

            } else {
                $kondisi = '';
                if ($code != '') {
                    $kondisi = 'dept_code like "%' . $code . '%"';
                }
                if ($desc != '') {
                    if ($kondisi != '') {
                        $kondisi .= ' and dept_desc like "%' . $desc . '%"';
                    } else {
                        $kondisi = 'dept_desc like "%' . $desc . '%"';
                    }
                }

                $data = DB::table('wo_mstr')
                    ->select(DB::raw('count(*) as jmlasset, wo_asset'))
                    ->whereBetween('wo_created_at',[$lalu,$skrg])
                    ->groupby('wo_asset')
                    ->orderby('jmlasset','desc')
                    ->paginate(5);


                return view('report.table-topprob', compact('data','$dataasset'));

            }
        }
    }

    //untuk Detail WO berdasarkan asset
    public function detailtopprob(Request $req)
    {
        
        if($req->ajax()){
            
             $data = DB::table('wo_mstr')
                ->where('wo_asset','=',$req->code)
                ->orderby('wo_created_at','asc')
                ->get();

            if($data){
                $output = '';
                $i = 1;
                foreach($data as $data){

                    $output .= '<tr>'.
                            '<td>'.$i.'</td>'.
                            '<td>'.$data->wo_nbr.'</td>'.
                            '<td>'.$data->wo_sr_nbr.'</td>'.
                            '<td>'.$data->wo_engineer1.'</td>'.
                            '<td>'.$data->wo_created_at.'</td>'.
                            '<td>'.$data->wo_failure_code1.'</td>'.
                            '</tr>';
                    $i += 1;
                }
                //dd($output);
                return response($output);
            }

        }
    }

    public function tophealthy() 
    {
        $non = DB::table('wo_mstr')
                ->select('wo_asset')
                ->groupby('wo_asset')
                ->get();

        $data = DB::table('asset_mstr')
                ->whereNotIn('asset_code',DB::table('wo_mstr')->groupby('wo_asset')->pluck('wo_asset')->toArray())
                ->limit(10)
                ->get();

        return view('report.tophealthy', compact('data'));
    }

    public function engsch(Request $req)
    {
        if (is_null($req->bulan)) {
            $tgl = Carbon::now('ASIA/JAKARTA')->toDateTimeString();
        } elseif ($req->stat == 'mundur') {
            $tgl = Carbon::createFromDate($req->bulan)->addMonth(-1)->toDateTimeString();
        } elseif ($req->stat == 'maju') {
            $tgl = Carbon::createFromDate($req->bulan)->addMonth(1)->toDateTimeString();
        } else {
            toast('Back to Home!!', 'error');
            return back();
        }
        
        $skrg = Carbon::createFromDate($tgl)->lastOfMonth()->day;
        $hari = Carbon::createFromDate($tgl)->startOfMonth()->isoFormat('dddd');
        $bulan = Carbon::createFromDate($tgl)->isoFormat('MMMM YYYY');
        
        switch ($hari) {
            case "Monday":
                $kosong = 0;
                break;
            case "Tuesday":
                $kosong = 1;
                break;
            case "Wednesday":
                $kosong = 2;
                break;
            case "Thursday":
                $kosong = 3;
                break;
            case "Friday":
                $kosong = 4;
                break;
            case "Saturday":
                $kosong = 5;
                break;
            case "Sunday":
                $kosong = 6;
                break;
        }

        $datawo = DB::table('wo_mstr')
                ->select('wo_nbr','wo_status','wo_schedule','wo_engineer1', 'wo_engineer2', 'wo_engineer3', 'wo_engineer4', 'wo_engineer5')
                ->selectRaw('EXTRACT(DAY FROM wo_schedule) as tgl')
                ->whereMonth('wo_schedule','=',date("m",strtotime($tgl)))
                ->whereYear('wo_schedule','=',date("Y",strtotime($tgl)))
                ->whereIn('wo_status',['open','plan','started'])
                ->get();

        return view('report.engsch',compact('skrg','hari','kosong','bulan','datawo'));
    }

    public function engsch1(Request $req)
    {
        $tgl = Carbon::createFromDate($req->bulan)->addMonth(-1)->toDateTimeString();
        
        $skrg = Carbon::createFromDate($tgl)->lastOfMonth()->day;
        $hari = Carbon::createFromDate($tgl)->startOfMonth()->isoFormat('dddd');
        $bulan = Carbon::createFromDate($tgl)->isoFormat('MMMM YYYY');
        
        switch ($hari) {
            case "Monday":
                $kosong = 0;
                break;
            case "Tuesday":
                $kosong = 1;
                break;
            case "Wednesday":
                $kosong = 2;
                break;
            case "Thursday":
                $kosong = 3;
                break;
            case "Friday":
                $kosong = 4;
                break;
            case "Saturday":
                $kosong = 5;
                break;
            case "Sunday":
                $kosong = 6;
                break;
        }

        $datawo = DB::table('wo_mstr')
                ->whereMonth('wo_schedule','=',date("m",strtotime($tgl)))
                ->get();
dd($tgl);

        return view('report.engsch',compact('skrg','hari','kosong','bulan','$datawo'));
    }

    public function engsch2(Request $req)
    {
        $tgl = Carbon::createFromDate($req->bulan)->addMonth(1)->toDateTimeString();
        
        $skrg = Carbon::createFromDate($tgl)->lastOfMonth()->day;
        $hari = Carbon::createFromDate($tgl)->startOfMonth()->isoFormat('dddd');
        $bulan = Carbon::createFromDate($tgl)->isoFormat('MMMM YYYY');
        
        switch ($hari) {
            case "Monday":
                $kosong = 0;
                break;
            case "Tuesday":
                $kosong = 1;
                break;
            case "Wednesday":
                $kosong = 2;
                break;
            case "Thursday":
                $kosong = 3;
                break;
            case "Friday":
                $kosong = 4;
                break;
            case "Saturday":
                $kosong = 5;
                break;
            case "Sunday":
                $kosong = 6;
                break;
        }
        return view('report.engsch',compact('skrg','hari','kosong','bulan'));
    }
}