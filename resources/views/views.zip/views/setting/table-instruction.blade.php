@forelse($data as $show)
<tr>
    <td>{{$show->ins_code}}</td>
    <td>{{$show->ins_desc}}</td>
    <td>
        <a href="" class="editarea2" id='editdata' data-toggle="modal" data-target="#editModal" 
        data-code="{{$show->ins_code}}" data-desc="{{$show->ins_desc}}" data-tool="{{$show->ins_tool}}" data-hour="{{$show->ins_hour}}"
        data-check="{{$show->ins_check}}" data-check_desc="{{$show->ins_check_desc}}" data-check_mea="{{$show->ins_check_mea}}"
        data-part="{{$show->ins_part}}" data-ref="{{$show->ins_ref}}">
            <i class="icon-table fa fa-edit fa-lg"></i></a>
        &ensp;
        <a href="" class="deletedata" data-toggle="modal" data-target="#deleteModal" data-code="{{$show->ins_code}}" data-desc="{{$show->ins_desc}}">
            <i class="icon-table fa fa-trash fa-lg"></i></a>
    </td>
</tr>
@empty
<tr>
    <td colspan="12" style="color:red">
        <center>No Data Available</center>
    </td>
</tr>
@endforelse
<tr>
  <td style="border: none !important;">
    {{ $data->links() }}
  </td>
</tr>