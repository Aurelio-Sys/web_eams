@php($eng = $ds->wo_engineer1)
@if(!is_null($ds->wo_engineer2))
    @php($eng .= ','.$ds->wo_engineer2)
@endif
@if(!is_null($ds->wo_engineer3))
    @php($eng .= ','.$ds->wo_engineer3)
@endif
@if(!is_null($ds->wo_engineer4))
    @php($eng .= ','.$ds->wo_engineer4)
@endif
@if(!is_null($ds->wo_engineer5))
    @php($eng .= ','.$ds->wo_engineer5)
@endif

@if($ds->wo_status == 'plan')
    <span class="badge badge-primary">{{$ds->wo_nbr}} - {{$eng}}</span>
@elseif($ds->wo_status == 'started')
    <span class="badge badge-success">{{$ds->wo_nbr}} - {{$eng}}</span>
@elseif($ds->wo_status == 'open')
    <span class="badge badge-warning">{{$ds->wo_nbr}} - {{$eng}}</span>
@endif

