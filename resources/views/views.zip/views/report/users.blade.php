<!DOCTYPE html>
<html lang="en">
<head>
    <title>Chart</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>

</head>
<body>
        {!! $chart->container() !!}

        {!! $chart->script() !!}

</body>
</html>