@extends('layout.newlayout')
@section('content-header')
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-9">
            <div class="d-flex justify-content-between">
                <h1 class="m-0 text-dark">Engineer Schedule</h1>
                <h1 class="m-0 text-dark">
                    <a href="/engsch?bulan={{$bulan}}&stat=mundur" ><i class="fas fa-angle-left"></i></a>
                    &ensp;&ensp;{{$bulan}}&ensp;&ensp;
                    <input type='hidden' name='bulan' id='bulan' value='{{$bulan}}'>
                    <a href="/engsch?bulan={{$bulan}}&stat=maju" ><i class="fas fa-angle-right"></i></a>
                </h1>
            </div>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
@endsection
@section('content')

<head>
    <title>Chart</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
</head>
<body>
<style>
    table {
        table-layout:fixed;
    }
    th {
        text-align: center;
    }
    td {
        width: 100px;
        height: 100px;
        text-align: right;
        overflow: auto;
    }
</style>
    <table class="table table-bordered">
    <thead class="table-info">
        <tr>
        <th scope="col">Monday</th>
        <th scope="col">Tuesday</th>
        <th scope="col">Wednesday</th>
        <th scope="col">Thursday</th>
        <th scope="col">Friday</th>
        <th scope="col">Saturday</th>
        <th scope="col">Sunday</th>
        </tr>
    </thead>
    <tbody>
        @php($i = 1)
        @for($x = 1; $x <= 5; $x++)
        <tr>
            @if($i == 1)
                @for($z = 1; $z <= $kosong; $z++)
                    <td></td>
                @endfor
            @else 
                @php($z = 1)
            @endif
            @for($y = $z; $y <= 7; $y++)
                @if($i > $skrg)
                    <td></td>
                @else
                    @php($ds = $datawo->where('tgl','=',$i)->count())
                    <td>
                        {{$i}}
                        <br>
                        @if($ds == 1)
                            @php($ds = $datawo->where('tgl','=',$i)->first())
                            @include('report.engsch-det')
                        @elseif($ds > 1)
                            @foreach($datawo as $ds)
                                @if($ds->tgl == $i)
                                    @include('report.engsch-det')
                                @endif
                            @endforeach
                        @endif
                    </td>
                @endif
                @php($i += 1)
            @endfor
            </tr>
        @endfor
    </tbody>
    </table>
    <div style="text-align: right">
        Work Order Status  :  
        <span class="badge badge-primary">Planned</span>
        <span class="badge badge-warning">Open</span>
        <span class="badge badge-success">Started</span>
    </div>
</body>

@endsection('content')