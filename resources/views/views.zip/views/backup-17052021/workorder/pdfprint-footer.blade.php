	
	<!--------------- INI UNTUK PRINT TEMPLATE --------------->
  <table style="width:750.4px; height:72.86px; margin-top:1.2cm; margin-left:-1cm;margin-right:0.6cm; margin-bottom:0.8cm" class="borderless">
  	
	
    <tr>
    <td style="width: 420px;font-family:sans-serif;">Tidak terima komplain diatas 7 hari</td>
    
    <td width="100px">
      
        
      
    </td>
    <td width="100px">
      
        
      
    </td>
    <td width="100px" style="text-align: center;">
     <p style="margin-top: 1em;"></p> 
        
      
    </td>
  </tr>
<tr>
    <td style="width: 390px;font-family:sans-serif;">Sejak barang diterima</td>    
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center;">
     <p style="margin-top: 1em;"></p> 
        
      
    </td>
  </tr>
<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>
<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>

<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>

<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>
	<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>


<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>
<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>

<tr style="height:3cm">
    <td style="width: 390px;"></td>
    <td width="100px">
    </td>
    <td width="100px">
    </td>
    <td width="100px" style="text-align: center; vertical-align:bottom">
    </td>
  </tr>
  

  <tr >
    <td style="width: 350px;"></td>
    <td width="110px" style="text-align: center;">
    <p style="margin-bottom:0;margin-top:0;font-family: sans-serif;">{{$printdata2->pic_wh}}</p>
    <p style="margin-top:0;margin-bottom:0;font-family: sans-serif;">{{$printdata2->pic_qc}}</p>
    <p style="margin-top:0;margin-bottom:0;font-family: sans-serif;">{{$printdata2->area_so}}</p>
    
    </td>
    <td width="110px">
    </td>
    <td width="110px" style="text-align: center;  vertical-align:bottom">
     <p style="margin-top: 1em;vertical-align:bottom;font-family: sans-serif;">{{$user->name}}</p> 
    </td>
  </tr>
  
</table>

