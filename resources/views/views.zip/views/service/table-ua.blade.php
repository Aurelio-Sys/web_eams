@forelse($dataua as $show)
<tr>
    <td style="text-align: center;">{{$show->sr_number}}</td>
    @if($show->wo_number == "")
    <td style="text-align: center;">-</td>
    @else
    <td style="text-align: center;">{{$show->wo_number}}</td>
    @endif
    <td style="text-align: center;">{{$show->asset_desc}}</td>
    <td style="text-align: center;">{{$show->dept_desc}}</td>
    <td style="text-align: center;">{{$show->sr_priority}}</td>
    <td style="text-align: center;">{{date('d-m-Y', strtotime($show->sr_created_at))}}</td>
    <td>
    <a href="" class="view" type="button" data-toggle="modal" data-target="#viewModal" data-srnumber="{{$show->sr_number}}" data-wonumber="{{$show->wo_number}}"><i class="icon-table fas fa-check-double fa-lg"></i></a>
    </td>
</tr>
@empty
<tr>
    <td colspan="12" style="color:red">
        <center>No Data Available</center>
    </td>
</tr>
@endforelse
<tr>
  <td style="border: none !important;">
    {{ $dataua->links() }}
  </td>
</tr>