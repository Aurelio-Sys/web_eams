@forelse($datas as $show)
<tr>
    <td style="text-align: center;">{{$show->sr_number}}</td>
    @if($show->wo_number == "")
    <td style="text-align: center;">-</td>
    @else
    <td style="text-align: center;">{{$show->wo_number}}</td>
    @endif
    <td style="text-align: center;">{{$show->asset_desc}}</td>
    @if($show->sr_status == 1)
    <td style="text-align: center;">Open</td>
    @elseif($show->sr_status == 2)
    <td style="text-align: center;">Assigned</td>
    @elseif($show->sr_status == 3)
    <td style="text-align: center;">Started</td>
    @elseif($show->sr_status == 4)
    <td style="text-align: center;">Finish</td>
    @elseif($show->sr_status == 5)
    <td style="text-align: center;">Closed</td>
    @endif
    <td style="text-align: center;">{{$show->dept_desc}}</td>
    <td style="text-align: center;">{{$show->sr_priority}}</td>
    <td style="text-align: center;">{{$show->req_by}}</td>
    <td style="text-align: center;">{{date('d-m-Y', strtotime($show->sr_created_at))}}</td>
    <td>
    <a href="" class="view" type="button" data-toggle="modal" data-target="#viewModal" data-srnumber="{{$show->sr_number}}" data-assetcode="{{$show->sr_assetcode}}" data-assetdesc="{{$show->asset_desc}}"
    data-failurecode1="{{$show->sr_failurecode1}}" data-failurecode2="{{$show->sr_failurecode2}}" data-failurecode3="{{$show->sr_failurecode3}}" 
    data-reqby="{{$show->username}}" data-srnote="{{$show->sr_note}}" data-priority="{{$show->sr_priority}}" data-rejectnote="{{$show->rejectnote}}"
    data-eng1="{{$show->u11}}" data-eng2="{{$show->u22}}" data-eng3="{{$show->u33}}" data-eng4="{{$show->u44}}" data-eng5="{{$show->u55}}"
    data-reqbyname="{{$show->req_by}}"><i class="icon-table far fa-eye fa-lg"></i></a>
    </td>
</tr>
@empty
<tr>
    <td colspan="12" style="color:red">
        <center>No Data Available</center>
    </td>
</tr>
@endforelse
<tr>
  <td style="border: none !important;" colspan="5">
    {{ $datas->links() }}
  </td>
</tr>