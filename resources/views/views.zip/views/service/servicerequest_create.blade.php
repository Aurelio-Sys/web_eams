@extends('layout.newlayout')
@section('content-header')

      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Service Request Create</h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
@endsection
@section('content')
  <!-- Flash Menu -->
  
  <div class="panel-body">
   <hr>
      <form method="post" id="srform" action="/inputsr">
        {{csrf_field()}}
        <div class="form-group row">
          <label for="assetcode" class="col-md-2 col-lg-6 col-form-label my-auto">Asset Code <span id="alert1" style="color: red; font-weight: 200;">* Please Select Asset Code</span></label>
          <div class="col-md-3 col-sm-12">
              <select id="assetcode" name="assetcode" class="form-control" required>
                <option value="">-- Select Asset Code --</option>
                @foreach($showasset as $show)
                  <option value="{{$show->asset_code}}">{{$show->asset_code.' => '.$show->asset_desc." - ".$show->asset_loc}}</option>
                @endforeach
              </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="failurecode1" class="col-md-2 col-lg-6 col-form-label my-auto">Failure Code 1 <span id="alert1" style="color: red; font-weight: 200;">*</span></label>
          <div class="col-md-3 col-sm-12">
            <select class="form-control iniselect" id="failurecode1" name="failurecode1">
              <option></option>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="failurecode2" class="col-md-2 col-lg-6 col-form-label my-auto">Failure Code 2</label>
          <div class="col-md-3 col-sm-12">
            <select class="form-control iniselect" id="failurecode2" name="failurecode2">
              <option></option>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="failurecode3" class="col-md-2 col-lg-6 col-form-label my-auto">Failure Code 3</label>
          <div class="col-md-3 col-sm-12">
            <select class="form-control iniselect" id="failurecode3" name="failurecode3">
                <option></option>
            </select>
          </div>
        </div>
        <!-- <div class="form-group row">
          <div class="col-md-2 col-lg-6 my-auto">
            <input type="checkbox" id="OtherCb"><label for="OtherCb" class="col-form-label ml-2">Other Failure Code</label>
          </div>
          <div class="col-md-3 col-sm-12">
            <textarea type="text" class="form-control" id="otherfailure" name="otherfailure" maxlength="250" autocomplete="off" disabled></textarea>
          </div>
        </div> -->
        <div class="form-group row">
          <label class="col-sm-12 col-lg-6 col-form-label">Note</label>
          <div class="col-sm-12 col-md-3">
            <textarea type="text" class="form-control" id="notesr" name="notesr" maxlength="250" autocomplete="off"></textarea>
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-12 col-lg-6 col-form-label">Priority <span id="alert1" style="color: red; font-weight: 200;">*</span></label>
          <div class="col-sm-12 col-md-3">
            <select  class="form-control" id="priority" name="priority" required>
              <option value="">--Select Data--</option>
              <option value="low">Low</optio>
              <option value="medium">Medium</optio>
              <option value="high">High</optio>
            </select>
          </div>
        </div>
        <!-- <div class="form-group row">
          <label class="col-sm-12 col-lg-6 col-form-label">Department</label>
          <div class="col-sm-12 col-md-3">
            <select  class="form-control" id="department" name="department" required>
              <option value="">--Select Department--</option>
              @foreach($dept as $show)
                <option value="{{$show->dept_code}}">{{$show->dept_desc}}</option>
              @endforeach
            </select>
          </div>
        </div> -->
        <div class="form-group row">
          <div class="col-sm-12 col-md-3 mx-auto">
            <button type="submit" id="btnsubmit" class="btn btn-success btn-block" style="color: white !important;">Create Service Request</button>
            <button type="button" class="btn btn-block btn-info" id="btnloading" style="display:none">
              <i class="fas fa-spinner fa-spin"></i> &nbsp;Loading
            </button>
          </div>
        </div>

      </form>
  </div>
  
@endsection

@section('scripts')
    <script>
      
      $(document).ready(function(){

        document.getElementById('OtherCb').onchange = function() {
          document.getElementById('otherfailure').disabled = !this.checked;
          document.getElementById('otherfailure').required = this.checked;
        };


        $("#numberfailure").select2({
            width : '100%',
            theme : 'bootstrap4',
        });

        $("#priority").select2({
            width : '100%',
            theme : 'bootstrap4',
        });

        $("#assetcode").select2({
            width : '100%',
            theme : 'bootstrap4',
            
        });
        $("#failurecode1").select2({
          width : '100%',
          // theme : 'bootstrap4',
          allowClear: true,
          placeholder: 'Select Failure Code',
          
        });

        $("#failurecode2").select2({
          width : '100%',
          // theme : 'bootstrap4',
          allowClear: true,
          placeholder: 'Select Failure Code',
          
        });

        $("#failurecode3").select2({
          width : '100%',
          // theme : 'bootstrap4',
          allowClear: true,
          placeholder: 'Select Failure Code',
          
        });

        $("#department").select2({
          width : '100%',
          theme : 'bootstrap4'
        });
      });

      // $('input').on('input', function(){

      // });

      // $(document).on('change', '#numberfailure', function(){
      //   var numberfailure = document.getElementById('numberfailure').value;
      //   $("#failurecode1").val('');
      //   $("#failurecode2").val('');
      //   $("#failurecode3").val('');

      //   var fl1 = document.getElementById('failurecode1').value;
      //   var fl2 = document.getElementById('failurecode2').value;
      //   var fl3 = document.getElementById('failurecode3').value;

      //   $("#failurecode1").select2({
      //     width : '100%',
      //     theme : 'bootstrap4',
      //     placeholder:'Select Failure Code',
      //     fl1
      //   });

      //   $("#failurecode2").select2({
      //     width : '100%',
      //     theme : 'bootstrap4',
      //     placeholder:'Select Failure Code',
      //     fl2
      //   });

      //   $("#failurecode3").select2({
      //     width : '100%',
      //     theme : 'bootstrap4',
      //     placeholder:'Select Failure Code',
      //     fl3
      //   });

      //   if(numberfailure == 1){
      //     // alert('1');
      //     document.getElementById('fl1').style.display = '';
      //     document.getElementById('fl2').style.display = 'none';
      //     document.getElementById('fl3').style.display = 'none';
      //     $("#failurecode1").attr('required',true);
      //     $("#failurecode2").attr('required',false);
      //     $("#failurecode3").attr('required',false);

      //   }else if(numberfailure == 2){
      //     // alert('2');
      //     document.getElementById('fl1').style.display = '';
      //     document.getElementById('fl2').style.display = '';
      //     document.getElementById('fl3').style.display = 'none';
          
      //     $("#failurecode1").attr('required',true);
      //     $("#failurecode2").attr('required',true);
      //     $("#failurecode3").attr('required',false);


      //   }else{
      //     // alert('3');
      //     document.getElementById('fl1').style.display = '';
      //     document.getElementById('fl2').style.display = '';
      //     document.getElementById('fl3').style.display = '';

      //     $("#failurecode1").attr('required',true);
      //     $("#failurecode2").attr('required',true);
      //     $("#failurecode3").attr('required',true);

      //   }
      // });


      $(document).on('change', '#assetcode', function(e) {
        var asset = document.getElementById('assetcode').value;
        var i = 0;
        var toAppend = '';
        document.getElementById('alert1').style.display = 'none';

        $("#failurecode1").val('');
        $("#failurecode2").val('');
        $("#failurecode3").val('');

        var fl1 = document.getElementById('failurecode1').value;
        var fl2 = document.getElementById('failurecode2').value;
        var fl3 = document.getElementById('failurecode3').value;

        $("#failurecode1").select2({
          width : '100%',
          // theme : 'bootstrap4',
          placeholder:'Select Failure Code',
          allowClear: true,
          fl1
        });

        $("#failurecode2").select2({
          width : '100%',
          // theme : 'bootstrap4',
          placeholder:'Select Failure Code',
          allowClear: true,
          fl2
        });

        $("#failurecode3").select2({
          width : '100%',
          // theme : 'bootstrap4',
          placeholder:'Select Failure Code',
          allowClear: true,
          fl3
        });

        $.ajax({
          url: "/failuresearch",
          data: {
            asset: asset,
          },
          success: function(data) {
            
            console.log(data);
              // $('#btnsubmit').prop('disabled', false);
              // document.getElementById('btnsubmit').style.display = '';
              
              // alert('row exists');
              // test();

              $('#failurecode1').html('').append(data).trigger('change');
              $('#failurecode2').html('').append(data).trigger('change');;
              $('#failurecode3').html('').append(data).trigger('change');;

              // console.log(globalasset);
                  
          }
          
        })
      });

      function validasiselect(){
        var failurecode1 = document.getElementById('failurecode1').value;
        var failurecode2 = document.getElementById('failurecode2').value;
        var failurecode3 = document.getElementById('failurecode3').value;

        if(failurecode1 != "" && failurecode2 == "" && failurecode3 == ""){
          var test = [failurecode1];
        }else if(failurecode1 != ""  && failurecode2 != "" && failurecode3 == ""){
          var test = [failurecode1, failurecode2];
        }else{
          var test  = [failurecode1, failurecode2, failurecode3];
        }

        var flg = true;
        // alert(test);
        // alert(test[0]);
        for(var i = 0; i < test.length; i++){
          
          if(test.indexOf(test[i], i + 1) >= 0){
            // alert(i);
            flg = false;
            break;
          }
        }

        // alert(flg);

        if(flg){
          // if(failurecode1 == "" && (failurecode2 != "" || failurecode3 != "")){
          //   document.getElementById('alert3').innerHTML = "* Please Select Failure Code 1";
          //   event.preventDefault();
          // }else{
            document.getElementById('alert2').innerHTML = "";
            $('#srform').submit();
          // }
        }else{

            if(failurecode1 == "" && (failurecode2 != "" || failurecode3 != "")){
                document.getElementById('alert2').innerHTML = "* Please Select Failure Code 1";
                event.preventDefault();
            }else{
                document.getElementById('alert2').innerHTML = "* Failure Code Duplicate";
                event.preventDefault();
            }
        }
      }




      $("#srform").submit(function (event) {
        // alert('ini ke trigger');

        
        
        let formSelectState = [];
        var fail1 = document.getElementById('failurecode1').value;
        var fail2 = document.getElementById('failurecode2').value;
        var fail3 = document.getElementById('failurecode3').value;

        if(fail1 == "" && fail2 == "" && fail3 == ""){

          swal.fire({
                    position: 'top-end',
                    icon: 'error',
                    title: 'Please select failure code',
                    toast: true,
                    showConfirmButton: false,
                    timer: 2000,
          })
          event.preventDefault();

        }else{
          
          if(fail1 != ''){
          formSelectState.push(fail1);
          }
          if(fail2 != ''){
            formSelectState.push(fail2);
          }
          if(fail3 != ''){
            formSelectState.push(fail3);
          }
          const counts = {};

          formSelectState.forEach(function (item, index) {
            if (counts[formSelectState[index]]) {
              counts[formSelectState[index]] += 1;
            } else {
              counts[formSelectState[index]] = 1;
            }
          });
          const dupl = Object.values(counts).filter(x => x != 1);

          
          if(dupl.length > 0){
            // eksekusi jika duplikat
            swal.fire({
                      position: 'top-end',
                      icon: 'error',
                      title: 'Failure Code Duplicate',
                      toast: true,
                      showConfirmButton: false,
                      timer: 2000,
            })

            event.preventDefault();
          }
          else{
            document.getElementById('btnsubmit').style.display = 'none';
            document.getElementById('btnloading').style.display = '';
          }
       
        }


        
      });
    </script>

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.12/css/select2.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.12/js/select2.min.js"></script>

    <script>
        
    </script>
@endsection