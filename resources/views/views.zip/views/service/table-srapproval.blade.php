@forelse($datas as $show)
<tr>
    <td style="text-align: center;">{{$show->sr_number}}</td>
    <td style="text-align: center;">{{$show->asset_desc}}</td>
    <td style="text-align: center;">{{$show->name}}</td>
    <td style="text-align: center;">{{$show->sr_priority}}</td>
    <td>
    <a href="" class="approval" type="button" data-toggle="modal" data-target="#viewModal" data-srnumber="{{$show->sr_number}}" data-assetcode="{{$show->sr_assetcode}}" data-assetdesc="{{$show->asset_desc}}"
    data-failurecode1="{{$show->sr_failurecode1}}" data-failurecode2="{{$show->sr_failurecode2}}" data-failurecode3="{{$show->sr_failurecode3}}" 
    data-reqby="{{$show->username}}" data-srnote="{{$show->sr_note}}" data-priority="{{$show->sr_priority}}" data-deptdesc="{{$show->dept_desc}}" data-deptcode="{{$show->dept_code}}"
    data-reqbyname="{{$show->req_by}}"><i class="icon-table fas fa-thumbs-up fa-lg"></i></a>
    </td>
</tr>
@empty
<tr>
    <td colspan="12" style="color:red">
        <center>No Data Available</center>
    </td>
</tr>
@endforelse
<tr>
  <td style="border: none !important;" colspan="5">
    {{ $datas->links() }}
  </td>
</tr>